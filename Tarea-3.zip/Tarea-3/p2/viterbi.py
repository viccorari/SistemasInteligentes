import sys
taglist=['O','I-GENE']
pi_prob=[]
word_rare=["_RARE_"]
tag_nos=[0.0,0.0]

def main():
	f=open('unigram.out','r')
	rare_pro={}
	for line in f:
		p=line.split()
		if(p[3] in word_rare):
			rare_pro[p[2]]=p[0]
	f.close()  
	maxi = -1.0
	tag_rare = ""
	for key in rare_pro:
		if maxi < rare_pro[key]:
			maxi = rare_pro[key]
			tag_rare = key          
	f=open('unigram.out','r')
	for line in f:
		i=0
		p=line.split()
		while(i<len(taglist)):
			if(p[2]==taglist[i]):
				c=float(p[0])
				tag_nos[i]=tag_nos[i]+c
				break
			i+=1
	f.close()
	f1=open('gene.test','r') 
	f2=open('gene_test.p2.out','w')
	k=0
	w='*'
	u='*'
	prev=1
	nos=0
	for line2 in f1:
		p=line2.split()
		for ww in p:
			line=ww
			break
		if line2 == '\n':
			k=0
			w='*'
			u='*'
			prev=1
			f2.write(line2)
		else:
			for v in taglist:
		 		q=trigram(w,u,v)
		 		e=emission(line,v)
		 		cur=prev*q*e
		 		pi_prob.append(cur)
		 	max_prob=max(pi_prob)
		 	if (max_prob!=0):
		 		index_v=pi_prob.index(max_prob)
		 		x=line+' '+taglist[index_v]+'\n'
		 		prev=max_prob
		 		del pi_prob[:]
		 		w=u
		 		u=taglist[index_v]
		 	else:
		 		len1=len(line)
				i=0
				isnum=0
				rtag=tag_rare
		 		x=line+' '+rtag+'\n'
		 		#prev=1
		 		del pi_prob[:]
		 		w=u
		 		u=rtag
	 		f2.write(x)
	 		nos+=1
	 		print "En linea:",nos
		 	
def trigram(w,u,v):
	f3=open('trigram.out','r+')
	f4=open('bigram.out','r+')
	c2=0
	c1=0
	for line in f3:	
		p=line.split()
		if(p[2]==w and p[3]==u and p[4]==v):
			c1=float(p[0])
			break
	for line in f4:	
		p=line.split()
		if(p[2]==w and p[3]==u):
			c2=float(p[0])
			break
	if(c2!=0):
		x=float(c1)/float(c2)
		return x
	else:
		return 0
	f3.close()
	f4.close()
	
def emission(w,v):
	f5=open('unigram.out','r+')
	c1=0
	for line in f5:
		p=line.split()
		if(p[3]==w and p[2]==v):
			c1=float(p[0])
	i=taglist.index(v)
	f5.close()
	if(c1==0):
		return 0.0
	else:
		x=float(c1)/tag_nos[i]		
		return x
	
if __name__=='__main__':
	main()	
	print "OK"
