Como ejecutar pregunta 2:

python splitcount.py
python viterbi.py 

Salida: gene_test.p2.out


