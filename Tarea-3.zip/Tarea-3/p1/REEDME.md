Como ejecutar pregunta 1:

python rare.py > rare.out
python count_freqs.py rare.out > count_rare.out
python simple_tagger.py > gene_dev.p1.out 
python eval_gene_tagger.py gene.key gene_dev.p1.out 

Salida: gene_dev.p1.out 

Found 2669 GENEs. Expected 642 GENEs; Correct: 424.

	     precision 	recall 		F1-Score
GENE:	 0.158861	0.660436	0.256116


