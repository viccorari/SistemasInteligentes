#!/usr/bin/python
from pprint import pprint

def put_rare (file_name,  word, n_occur):
    f = open(file_name,'r')
    dic = {}
    for line in f:
        line = line.split()
        if line:
            line[0]=line[0].strip(" ")
            line[1]=line[1].strip(" ")
            if line[0] in dic:
                dic [line[0]] += 1
            else:
                dic [line[0]] = 1
    f.close()
    f = open(file_name,'r')
    for line in f:
        line = line.split()
        if line:
            if dic[line[0]] < n_occur:
                print word, line[1]
            else:
                print line[0], line[1]
        else:
            print ""
    f.close()
        
put_rare ("gene.train" , "_RARE_", 5)
