#!/usr/bin/python
from pprint import pprint

def put_rare (file_name, n_occur):
	f = open(file_name,'r')
	dic = {}
	for line in f:
		line = line.split()
		if line:
			line[0]=line[0].strip(" ")
			line[1]=line[1].strip(" ")
			if line[0] in dic:
				dic [line[0]] += 1
			else:
				dic [line[0]] = 1
	f.close()
	f = open(file_name,'r')
	for line in f:
		line = line.split()
		if line:
			if dic[line[0]] < n_occur:
				len1=len(line[0])
				i=0
				isnum=0
				while(i<len1):
					if(line[0][i].isdigit()):
						isnum=1
					i=i+1
				if(isnum==1):
					rtag='_NUMERIC_'
				elif(line[0].isupper()):
					rtag='_ALLCAPS_'
				elif(line[0][len1-1].isupper() and line[0][:len1-1].islower()):
					rtag='_LASTCAP_'
				else:
					rtag='_RARE_'
				print line[0], rtag
			else:
				print line[0], line[1]
		else:
			print ""
	f.close()

put_rare ("gene.train" , 5)





