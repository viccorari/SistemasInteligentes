#! /usr/bin/python
import sys

def split_count(file_c):
	f=open(file_c,'r')
	f2=open('trigram.out','w')
	f3=open('bigram.out','w')
	f4=open('unigram.out','w')
	for line in f:
		p=line.split()
		if(p[1]=='3-GRAM'):	
			f2.write(line)
		if(p[1]=='2-GRAM'):
			f3.write(line)
		if(p[1]=='WORDTAG'):
			f4.write(line)

split_count("count_rare_esp.out")
    
