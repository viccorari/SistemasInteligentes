Como ejecutar pregunta 3:

python rare_esp.py > rare_esp.out
python count_freqs.py rare_esp.out > count_rare_esp.out
python simple_tagger.py > gene_dev3.out 
python splitcount.py
python viterbi.py 

Salida: gene_test.p3.out
