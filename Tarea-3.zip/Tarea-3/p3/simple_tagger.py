#!/usr/bin/python
from pprint import pprint

def s_tagger (file_count, file_list):
    li = open (file_list, "r")
    co = open (file_count, "r")
    total_tag = {}
    dic_tag = {}
    for line in co:
        line = line.split()
        for i in range(len(line)):
            line[i] = line[i].strip(" ")
        if line[1] == "WORDTAG":
            if line[2] in total_tag:
                total_tag[line[2]] += float(line[0])
            else:
                total_tag[line[2]] = float(line[0])
    co.close()
    co = open (file_count, "r")
    for line in co:
        line = line.split()
        for i in range(len(line)):
            line[i] = line[i].strip(" ")
        if line[1] == "WORDTAG":
            if not line[3] in dic_tag:
                dic_tag[line[3]] = {} 
                for keys in total_tag:
                    dic_tag[line[3]][keys] = 0
            dic_tag[line[3]][line[2]] += float(line[0])/total_tag[line[2]]
    co.close()
    #pprint(dic_tag) 
    for line in li:
        line = line.strip(" ").strip('\n')
        if line:
            if not line in dic_tag:        
                line_ = "_RARE_"
            else:
                line_ = line
            maxi = -1.0
            n_maxi = ""
            for key in total_tag:
                if maxi < dic_tag[line_][key]:
                    maxi = dic_tag[line_][key]
                    n_maxi = key
            print line,n_maxi
        else:
            print ""      
    #for key in dic_tag                         
    #pprint(dic_tag)    
    #pprint(total_tag)
    li.close()
    
s_tagger("count_rare_esp.out","gene.dev")
