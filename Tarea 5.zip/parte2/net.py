from __future__ import print_function

import numpy as np
import tflearn as tf

from tflearn.data_utils import load_csv
data, labels = load_csv('car.csv', target_column=6,
                        categorical_labels=True, n_classes=4)

def preprocess(data):
  for i in range(len(data)):
    if data[i][0] == 'vhigh':
        data[i][0] = 4.
    elif data[i][0] == 'high':
        data[i][0] = 3.
    elif data[i][0] == 'med':
        data[i][0] = 2.
    else: data[i][0] = 1.

    if data[i][1] == 'vhigh':
        data[i][1] = 4.
    elif data[i][1] == 'high':
        data[i][1] = 3.
    elif data[i][1] == 'med':
        data[i][1] = 2.
    else: data[i][1] = 1.

    if data[i][2] == '2':
        data[i][2] = 2.
    elif data[i][2] == '3':
        data[i][2] = 3.
    elif data[i][2] == '4':
        data[i][2] = 4.
    else: data[i][2] = 5.

    if data[i][3] == '2':
        data[i][3] = 2.
    elif data[i][3] == '4':
        data[i][3] = 4.
    else: data[i][3] = 5.

    if data[i][4] == 'small':
        data[i][4] = 1.
    elif data[i][4] == 'med':
        data[i][4] = 2.
    else: data[i][4] = 3.

    if data[i][5] == 'low':
        data[i][5] = 1.
    elif data[i][5] == 'med':
        data[i][5] = 2.
    else: data[i][5] = 3.
  return np.array(data, dtype=np.float32)

data = preprocess(data)

net = tf.input_data(shape=[None, 6])
net = tf.fully_connected(net, 64, activation='sigmoid')
net = tf.fully_connected(net, 64, activation='sigmoid')
net = tf.fully_connected(net, 4, activation='softmax',bias="True")
net = tf.regression(net)

model = tf.DNN(net)
model.fit(data, labels, n_epoch=20, show_metric=False, batch_size=1)

t1 = ["low","low","4","2","big","high"]
t2 = ["low","low","5more","4","med","med"]
t3 = ["low","low","5more","more","big","low"]
t4 = ["high","vhigh","3","4","big","med"]
clases = ["unacc","acc","good","vgood"]

t1, t2, t3, t4 = preprocess([t1, t2, t3, t4])

pred = model.predict([t1, t2, t3, t4])
for i in range(4):
    print("Prueba ",i+1,":")
    for j in range(len(clases)):
        print("Clase",clases[j],":\t", pred[i][j])
    print("Max: ",max(pred[i]), "Class:", clases[pred[i].index(max(pred[i]))])
    print("------------------------------------------")

